import { NextRequest, NextResponse } from 'next/server'
import { Resend } from 'resend'

// Initialize Resend - will use RESEND_API_KEY environment variable if available
const resend = new Resend(process.env.RESEND_API_KEY)

interface ContactFormData {
  name: string
  email: string
  company?: string
  projectType?: string
  budget?: string
  timeline?: string
  message: string
}

export async function POST(request: NextRequest) {
  try {
    const body: ContactFormData = await request.json()
    
    // Validate required fields
    if (!body.name || !body.email || !body.message) {
      return NextResponse.json(
        { error: 'Nombre, email y mensaje son requeridos' },
        { status: 400 }
      )
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(body.email)) {
      return NextResponse.json(
        { error: 'Email inválido' },
        { status: 400 }
      )
    }

    // Build email content
    const emailHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #0a0a0a; color: #ffffff; padding: 40px; }
          .container { max-width: 600px; margin: 0 auto; }
          .header { border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 20px; margin-bottom: 30px; }
          .logo { font-size: 24px; font-weight: 300; letter-spacing: 0.2em; }
          .field { margin-bottom: 20px; }
          .label { font-size: 12px; color: rgba(255,255,255,0.4); text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 5px; }
          .value { font-size: 16px; color: rgba(255,255,255,0.9); }
          .message-box { background: rgba(255,255,255,0.05); padding: 20px; border-left: 2px solid rgba(255,255,255,0.2); }
          .footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1); font-size: 12px; color: rgba(255,255,255,0.3); }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">WEBNOX</div>
            <div style="color: rgba(255,255,255,0.4); font-size: 12px; margin-top: 5px;">Nueva solicitud de contacto</div>
          </div>

          <div class="field">
            <div class="label">Nombre</div>
            <div class="value">${body.name}</div>
          </div>

          <div class="field">
            <div class="label">Email</div>
            <div class="value"><a href="mailto:${body.email}" style="color: #ffffff;">${body.email}</a></div>
          </div>

          ${body.company ? `
          <div class="field">
            <div class="label">Empresa / Organización</div>
            <div class="value">${body.company}</div>
          </div>
          ` : ''}

          ${body.projectType ? `
          <div class="field">
            <div class="label">Tipo de proyecto</div>
            <div class="value">${body.projectType}</div>
          </div>
          ` : ''}

          ${body.budget ? `
          <div class="field">
            <div class="label">Presupuesto</div>
            <div class="value">${body.budget}</div>
          </div>
          ` : ''}

          ${body.timeline ? `
          <div class="field">
            <div class="label">Plazo</div>
            <div class="value">${body.timeline}</div>
          </div>
          ` : ''}

          <div class="field">
            <div class="label">Mensaje</div>
            <div class="value message-box">${body.message.replace(/\n/g, '<br>')}</div>
          </div>

          <div class="footer">
            Este mensaje fue enviado desde el formulario de contacto de webnox.online
          </div>
        </div>
      </body>
      </html>
    `

    const emailText = `
NUEVA SOLICITUD DE CONTACTO - WEBNOX
=====================================

Nombre: ${body.name}
Email: ${body.email}
${body.company ? `Empresa: ${body.company}` : ''}
${body.projectType ? `Tipo de proyecto: ${body.projectType}` : ''}
${body.budget ? `Presupuesto: ${body.budget}` : ''}
${body.timeline ? `Plazo: ${body.timeline}` : ''}

MENSAJE:
${body.message}

---
Enviado desde webnox.online
    `.trim()

    // Try to send email with Resend
    if (process.env.RESEND_API_KEY) {
      const { data, error } = await resend.emails.send({
        from: 'WEBNOX Contact <onboarding@resend.dev>',
        to: ['programaciones.mark@gmail.com'],
        subject: `Nuevo contacto: ${body.name} - WEBNOX`,
        html: emailHtml,
        text: emailText,
        replyTo: body.email,
      })

      if (error) {
        console.error('Resend error:', error)
        return NextResponse.json(
          { error: 'Error al enviar el mensaje. Por favor, intenta de nuevo.' },
          { status: 500 }
        )
      }

      console.log('Email sent successfully:', data)
      return NextResponse.json({ 
        success: true, 
        message: 'Mensaje enviado correctamente',
        id: data?.id 
      })
    } else {
      // If no API key, log the email and return success for demo
      console.log('='.repeat(50))
      console.log('CONTACT FORM SUBMISSION (No Resend API Key)')
      console.log('='.repeat(50))
      console.log('To: programaciones.mark@gmail.com')
      console.log('From:', body.email)
      console.log('Name:', body.name)
      console.log('Company:', body.company || 'N/A')
      console.log('Project Type:', body.projectType || 'N/A')
      console.log('Budget:', body.budget || 'N/A')
      console.log('Timeline:', body.timeline || 'N/A')
      console.log('Message:', body.message)
      console.log('='.repeat(50))
      
      // For demo purposes without API key, we still return success
      // In production, you would want to require the API key
      return NextResponse.json({ 
        success: true, 
        message: 'Mensaje recibido correctamente (modo demo)',
        note: 'Configure RESEND_API_KEY para envío real de emails'
      })
    }

  } catch (error) {
    console.error('Contact API error:', error)
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
