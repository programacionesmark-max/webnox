import type { Metadata } from "next";
import { Inter, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
  weight: ["300", "400", "500", "600", "700", "800", "900"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "WEBNOX® | Digital Engineering Studio",
  description: "Estudio de ingeniería digital de alta precisión. Desarrollo web, diseño y consultoría para empresas que buscan excelencia técnica.",
  keywords: ["WEBNOX", "Digital Engineering", "Web Development", "Design", "Consulting", "React", "Next.js", "TypeScript"],
  authors: [{ name: "WEBNOX" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "WEBNOX® | Digital Engineering Studio",
    description: "Estudio de ingeniería digital de alta precisión",
    url: "https://webnox.dev",
    siteName: "WEBNOX",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "WEBNOX® | Digital Engineering Studio",
    description: "Estudio de ingeniería digital de alta precisión",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning className="dark">
      <body
        className={`${inter.variable} ${geistMono.variable} font-sans antialiased bg-background text-foreground overflow-x-hidden`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
