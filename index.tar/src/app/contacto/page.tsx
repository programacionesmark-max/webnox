'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowLeft, Mail, MapPin, Clock, Send, Check, AlertCircle } from 'lucide-react'
import Link from 'next/link'
import { Navbar } from '@/components/layout/Navbar'
import { Footer } from '@/components/layout/Footer'
import { 
  GalacticBackground, 
  ParticleConnections, 
  CustomCursor, 
  GrainOverlay,
  ScrollProgress,
  OrbitingElements
} from '@/components/layout/PageEffects'

const easeLux = [0.16, 1, 0.3, 1] as const

const contactInfo = [
  { icon: Mail, label: 'Email', value: 'hello@webnox.online', href: 'mailto:hello@webnox.online' },
  { icon: MapPin, label: 'Ubicación', value: 'Sint Willebrord, Países Bajos' },
  { icon: Clock, label: 'Respuesta', value: 'En menos de 24h' },
]

const projectTypes = [
  'Landing page',
  'Sitio corporativo',
  'E-commerce',
  'Web app',
  'Rediseño',
  'Otro',
]

const budgets = [
  '€500 - €1,000',
  '€1,000 - €1,500',
  '€1,500 - €2,300',
  'Más de €2,300',
  'Suscripción mensual',
]

const timelines = [
  'Urgente (< 1 semana)',
  '1-2 semanas',
  '2-4 semanas',
  'Más de 1 mes',
  'Sin fecha definida',
]

export default function ContactoPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    projectType: '',
    budget: '',
    timeline: '',
    message: '',
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError(null)

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Error al enviar el mensaje')
      }

      setIsSubmitted(true)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al enviar el mensaje')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }))
  }

  return (
    <main className="relative min-h-screen bg-[#050505] text-white overflow-x-hidden">
      <GalacticBackground />
      <ParticleConnections />
      <OrbitingElements />
      <GrainOverlay />
      <ScrollProgress />
      <CustomCursor />
      <Navbar />

      <div className="relative z-10 pt-32 pb-20">
        <div className="max-w-6xl mx-auto px-6 sm:px-12 lg:px-24">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-16"
          >
            <Link
              href="/"
              className="inline-flex items-center gap-2 text-white/30 hover:text-white transition-colors mb-8 text-sm"
            >
              <ArrowLeft size={14} />
              Inicio
            </Link>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-light mb-4">Contacto</h1>
            <p className="text-white/30 max-w-lg">
              Cuéntanos sobre tu proyecto. Solo aceptamos trabajos donde podemos garantizar resultados.
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-5 gap-12">
            {/* Sidebar */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="lg:col-span-2 space-y-8"
            >
              <div>
                <h2 className="text-xs tracking-[0.15em] text-white/20 uppercase mb-6">Información</h2>
                <div className="space-y-6">
                  {contactInfo.map((info, i) => (
                    <div key={i} className="flex items-start gap-4">
                      <info.icon size={16} className="text-white/30 mt-0.5" />
                      <div>
                        <div className="text-xs text-white/30 mb-1">{info.label}</div>
                        {info.href ? (
                          <a href={info.href} className="text-sm hover:text-white/70 transition-colors">
                            {info.value}
                          </a>
                        ) : (
                          <div className="text-sm">{info.value}</div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-6 border border-white/5">
                <h3 className="text-sm mb-4">Disponibilidad</h3>
                <div className="flex items-center gap-2 mb-3">
                  <span className="w-1.5 h-1.5 bg-green-400 rounded-full" />
                  <span className="text-sm text-white/50">Aceptando proyectos</span>
                </div>
                <p className="text-xs text-white/30">
                  2 slots disponibles. Tiempo de espera estimado: 1-2 semanas.
                </p>
              </div>

              <div className="p-6 border border-white/5">
                <h3 className="text-sm mb-4">Qué incluye</h3>
                <ul className="space-y-2">
                  {['100% código propio', 'Soporte post-lanzamiento', 'Hosting primer año', 'Sin costes ocultos'].map((item, i) => (
                    <li key={i} className="flex items-center gap-2 text-xs text-white/40">
                      <Check size={10} className="text-white/30" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>

            {/* Form */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="lg:col-span-3"
            >
              {isSubmitted ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="p-12 text-center border border-white/5"
                >
                  <div className="w-12 h-12 mx-auto mb-6 flex items-center justify-center border border-white/20 rounded-full">
                    <Check size={24} className="text-white/60" />
                  </div>
                  <h2 className="text-2xl font-light mb-4">Mensaje enviado</h2>
                  <p className="text-white/40 mb-8 max-w-sm mx-auto text-sm">
                    Recibido. Te responderemos en menos de 24 horas laborables.
                  </p>
                  <Link
                    href="/"
                    className="inline-flex items-center gap-2 px-6 py-3 border border-white/10 text-sm tracking-wider uppercase hover:border-white/30 transition-colors"
                  >
                    Volver al inicio
                  </Link>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid sm:grid-cols-2 gap-6">
                    <div>
                      <label className="text-xs text-white/30 block mb-2">Nombre *</label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="w-full bg-transparent border-b border-white/10 py-3 text-sm focus:border-white/30 focus:outline-none transition-colors"
                        placeholder="Tu nombre"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-white/30 block mb-2">Email *</label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full bg-transparent border-b border-white/10 py-3 text-sm focus:border-white/30 focus:outline-none transition-colors"
                        placeholder="tu@email.com"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-white/30 block mb-2">Empresa / Organización</label>
                    <input
                      type="text"
                      name="company"
                      value={formData.company}
                      onChange={handleChange}
                      className="w-full bg-transparent border-b border-white/10 py-3 text-sm focus:border-white/30 focus:outline-none transition-colors"
                      placeholder="Nombre (opcional)"
                    />
                  </div>

                  <div className="grid sm:grid-cols-3 gap-6">
                    <div>
                      <label className="text-xs text-white/30 block mb-2">Tipo de proyecto</label>
                      <select
                        name="projectType"
                        value={formData.projectType}
                        onChange={handleChange}
                        className="w-full bg-transparent border-b border-white/10 py-3 text-sm focus:border-white/30 focus:outline-none transition-colors appearance-none cursor-pointer"
                      >
                        <option value="" className="bg-[#0a0a0a]">Seleccionar</option>
                        {projectTypes.map((type) => (
                          <option key={type} value={type} className="bg-[#0a0a0a]">{type}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-white/30 block mb-2">Presupuesto</label>
                      <select
                        name="budget"
                        value={formData.budget}
                        onChange={handleChange}
                        className="w-full bg-transparent border-b border-white/10 py-3 text-sm focus:border-white/30 focus:outline-none transition-colors appearance-none cursor-pointer"
                      >
                        <option value="" className="bg-[#0a0a0a]">Seleccionar</option>
                        {budgets.map((b) => (
                          <option key={b} value={b} className="bg-[#0a0a0a]">{b}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="text-xs text-white/30 block mb-2">Plazo</label>
                      <select
                        name="timeline"
                        value={formData.timeline}
                        onChange={handleChange}
                        className="w-full bg-transparent border-b border-white/10 py-3 text-sm focus:border-white/30 focus:outline-none transition-colors appearance-none cursor-pointer"
                      >
                        <option value="" className="bg-[#0a0a0a]">Seleccionar</option>
                        {timelines.map((t) => (
                          <option key={t} value={t} className="bg-[#0a0a0a]">{t}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-white/30 block mb-2">Cuéntanos sobre tu proyecto *</label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      rows={5}
                      className="w-full bg-transparent border-b border-white/10 py-3 text-sm focus:border-white/30 focus:outline-none transition-colors resize-none"
                      placeholder="Describe tu proyecto, objetivos y cualquier detalle relevante..."
                    />
                  </div>

                  {error && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center gap-3 p-4 border border-red-500/30 bg-red-500/5"
                    >
                      <AlertCircle size={16} className="text-red-400 flex-shrink-0" />
                      <p className="text-sm text-red-400">{error}</p>
                    </motion.div>
                  )}

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 bg-white text-black text-sm tracking-wider uppercase hover:bg-white/90 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <>
                        <span className="w-3 h-3 border border-black border-t-transparent rounded-full animate-spin" />
                        Enviando...
                      </>
                    ) : (
                      <>
                        <Send size={14} />
                        Enviar solicitud
                      </>
                    )}
                  </button>

                  <p className="text-center text-white/20 text-xs">
                    Al enviar aceptas nuestra política de privacidad. Sin spam.
                  </p>
                </form>
              )}
            </motion.div>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
