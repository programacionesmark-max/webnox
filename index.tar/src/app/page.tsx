'use client'

import { useState, useEffect, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ArrowRight, ArrowUpRight, Minus } from 'lucide-react'
import Link from 'next/link'
import { Navbar } from '@/components/layout/Navbar'
import { Footer } from '@/components/layout/Footer'
import { 
  GalacticBackground, 
  ParticleConnections, 
  CustomCursor, 
  GrainOverlay,
  ScrollProgress,
  OrbitingElements
} from '@/components/layout/PageEffects'

const easeLux = [0.16, 1, 0.3, 1] as const

// Elegant Loader
function Loader({ onComplete }: { onComplete: () => void }) {
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval)
          setTimeout(onComplete, 300)
          return 100
        }
        return prev + Math.random() * 15 + 5
      })
    }, 100)

    return () => clearInterval(interval)
  }, [onComplete])

  return (
    <motion.div
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#050505]"
      exit={{ opacity: 0, transition: { duration: 0.6, ease: easeLux } }}
    >
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center"
      >
        <div className="mb-12 text-sm tracking-[0.3em] text-white/30 font-light">WEBNOX</div>
        <div className="w-48 h-px bg-white/5 relative overflow-hidden">
          <motion.div
            className="absolute inset-y-0 left-0 bg-white/80"
            animate={{ width: `${Math.min(progress, 100)}%` }}
          />
        </div>
      </motion.div>
    </motion.div>
  )
}

// Elegant Hero
function HeroSection() {
  const [scrambledText, setScrambledText] = useState('Digital.')
  const finalText = 'Digital.'

  const handleScramble = useCallback(() => {
    let iteration = 0
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    const interval = setInterval(() => {
      setScrambledText(
        finalText.split('').map((char, idx) => {
          if (idx < iteration) return finalText[idx]
          return chars[Math.floor(Math.random() * chars.length)]
        }).join('')
      )
      if (iteration >= finalText.length) {
        clearInterval(interval)
        setScrambledText(finalText)
      }
      iteration += 1 / 2
    }, 40)
  }, [])

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="relative z-10 w-full max-w-6xl mx-auto px-6 sm:px-12 lg:px-24 py-24">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, ease: easeLux }}
          className="text-center"
        >
          {/* Status indicator */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex items-center justify-center gap-3 mb-16"
          >
            <span className="w-1 h-1 bg-white/60 rounded-full" />
            <span className="text-xs tracking-[0.2em] text-white/30 uppercase">
              Aceptando proyectos · Q1 2026
            </span>
          </motion.div>

          {/* Main heading */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 1, ease: easeLux }}
            className="text-6xl sm:text-7xl md:text-8xl lg:text-9xl font-light tracking-[-0.03em] leading-[0.9] mb-8"
          >
            Precisión<br />
            <span
              onMouseEnter={handleScramble}
              className="cursor-pointer inline-block transition-colors duration-300 hover:text-white/70"
            >
              {scrambledText}
            </span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="text-lg sm:text-xl text-white/30 font-light max-w-md mx-auto mb-16 leading-relaxed"
          >
            Ingeniería digital de precisión.<br />
            Sin plantillas. Sin compromisos.
          </motion.p>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.8 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6"
          >
            <Link
              href="/contacto"
              className="group flex items-center gap-3 px-8 py-4 bg-white text-black text-sm tracking-widest uppercase font-medium hover:bg-white/90 transition-colors"
            >
              Iniciar proyecto
              <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link
              href="/proyectos"
              className="group flex items-center gap-3 px-8 py-4 text-sm tracking-widest uppercase text-white/50 hover:text-white transition-colors"
            >
              Ver trabajos
              <ArrowUpRight size={14} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </Link>
          </motion.div>
        </motion.div>

        {/* Scroll hint */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-12 left-1/2 -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 8, 0], opacity: [0.3, 0.6, 0.3] }}
            transition={{ duration: 3, repeat: Infinity }}
            className="w-px h-12 bg-gradient-to-b from-white/20 to-transparent"
          />
        </motion.div>
      </div>
    </section>
  )
}

// Navigation Cards
function NavigationSection() {
  const sections = [
    { 
      number: '01', 
      title: 'Proyectos', 
      desc: 'Portfolio de trabajos seleccionados',
      href: '/proyectos'
    },
    { 
      number: '02', 
      title: 'Stack', 
      desc: 'Tecnologías y metodología',
      href: '/stack'
    },
    { 
      number: '03', 
      title: 'Planes', 
      desc: 'Inversión y suscripciones',
      href: '/planes'
    },
    { 
      number: '04', 
      title: 'Contacto', 
      desc: 'Iniciar conversación',
      href: '/contacto'
    },
  ]

  return (
    <section className="relative py-24 border-t border-white/5">
      <div className="max-w-6xl mx-auto px-6 sm:px-12 lg:px-24">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-px bg-white/5">
          {sections.map((section, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.6 }}
            >
              <Link
                href={section.href}
                className="group block p-8 sm:p-10 bg-[#050505] hover:bg-white/[0.02] transition-all duration-500"
              >
                <div className="flex items-start justify-between mb-6">
                  <span className="font-mono text-xs text-white/20">{section.number}</span>
                  <ArrowUpRight size={16} className="text-white/0 group-hover:text-white/30 transition-colors" />
                </div>
                <h3 className="text-xl sm:text-2xl font-light mb-2 group-hover:text-white transition-colors">{section.title}</h3>
                <p className="text-sm text-white/30 group-hover:text-white/50 transition-colors">{section.desc}</p>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

// Featured Work
function FeaturedWork() {
  const projects = [
    {
      title: 'NØMADIC CO.',
      category: 'E-Commerce',
      url: 'nomadic.website',
      image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1000&q=80'
    },
    {
      title: 'LA CENA BY NOLA',
      category: 'Restaurante',
      url: 'lacenabynola.com',
      image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1000&q=80'
    },
    {
      title: 'A CONTRABARRA',
      category: 'Hospitalidad',
      url: 'acontrabarra.es',
      image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1000&q=80'
    },
  ]

  return (
    <section className="relative py-24 border-t border-white/5">
      <div className="max-w-6xl mx-auto px-6 sm:px-12 lg:px-24">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex items-end justify-between mb-16"
        >
          <div>
            <span className="text-xs tracking-[0.2em] text-white/20 uppercase">Proyectos</span>
            <h2 className="text-3xl sm:text-4xl font-light mt-2">Trabajos seleccionados</h2>
          </div>
          <Link
            href="/proyectos"
            className="group hidden sm:flex items-center gap-2 text-sm text-white/30 hover:text-white transition-colors"
          >
            Ver todos
            <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </motion.div>

        {/* Projects */}
        <div className="grid md:grid-cols-3 gap-6">
          {projects.map((project, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15, duration: 0.6 }}
            >
              <Link href="/proyectos" className="group block">
                <div className="relative aspect-[4/5] overflow-hidden mb-6">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent opacity-60" />
                </div>
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-xs tracking-wider text-white/30 uppercase mb-1">{project.category}</p>
                    <h3 className="text-lg font-light group-hover:text-white/70 transition-colors">{project.title}</h3>
                  </div>
                  <ArrowUpRight size={18} className="text-white/0 group-hover:text-white/40 transition-colors mt-1" />
                </div>
              </Link>
            </motion.div>
          ))}
        </div>

        {/* Mobile link */}
        <div className="mt-12 sm:hidden">
          <Link
            href="/proyectos"
            className="group flex items-center gap-2 text-sm text-white/30 hover:text-white transition-colors"
          >
            Ver todos los proyectos
            <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </div>
    </section>
  )
}

// Stats
function StatsSection() {
  const stats = [
    { value: '100', label: 'Lighthouse' },
    { value: '<100ms', label: 'LCP' },
    { value: '18', label: 'Regiones' },
    { value: '∞', label: 'Posibilidades' },
  ]

  return (
    <section className="relative py-24 border-t border-white/5 bg-white/[0.005]">
      <div className="max-w-6xl mx-auto px-6 sm:px-12 lg:px-24">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-4">
          {stats.map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.6 }}
              className="text-center"
            >
              <div className="text-4xl sm:text-5xl font-light mb-2">{stat.value}</div>
              <div className="text-xs tracking-[0.15em] text-white/30 uppercase">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

// Philosophy
function PhilosophySection() {
  return (
    <section className="relative py-24 border-t border-white/5">
      <div className="max-w-6xl mx-auto px-6 sm:px-12 lg:px-24">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-2xl"
        >
          <span className="text-xs tracking-[0.2em] text-white/20 uppercase">Filosofía</span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-light mt-4 mb-8 leading-tight">
            El código es capital.
          </h2>
          <p className="text-lg text-white/30 leading-relaxed mb-8">
            No usamos plantillas. Cada línea de código está escrita específicamente para tu proyecto. 
            Esto significa rendimiento optimizado, seguridad reforzada, y total control sobre tu activo digital.
          </p>
          <Link
            href="/stack"
            className="group inline-flex items-center gap-2 text-sm tracking-wider text-white/50 hover:text-white transition-colors"
          >
            Ver metodología
            <Minus size={14} className="rotate-[-45deg] group-hover:rotate-0 transition-transform" />
          </Link>
        </motion.div>
      </div>
    </section>
  )
}

// CTA
function CTASection() {
  return (
    <section className="relative py-24 border-t border-white/5">
      <div className="max-w-6xl mx-auto px-6 sm:px-12 lg:px-24 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl sm:text-4xl font-light mb-4">¿Hablamos?</h2>
          <p className="text-white/30 mb-10 max-w-md mx-auto">
            Solo aceptamos proyectos donde podemos garantizar resultados excepcionales.
          </p>
          <Link
            href="/contacto"
            className="group inline-flex items-center gap-3 px-10 py-5 border border-white/20 text-sm tracking-widest uppercase hover:bg-white hover:text-black transition-all duration-300"
          >
            Iniciar conversación
            <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </motion.div>
      </div>
    </section>
  )
}

export default function Home() {
  const [isLoading, setIsLoading] = useState(true)

  return (
    <main className="relative min-h-screen bg-[#050505] text-white overflow-x-hidden">
      <AnimatePresence>
        {isLoading && <Loader onComplete={() => setIsLoading(false)} />}
      </AnimatePresence>

      {/* Elegant background effects */}
      <GalacticBackground />
      <ParticleConnections />
      <OrbitingElements />
      <GrainOverlay />
      <ScrollProgress />
      <CustomCursor />

      <Navbar />

      <div className="relative z-10">
        <HeroSection />
        <NavigationSection />
        <FeaturedWork />
        <StatsSection />
        <PhilosophySection />
        <CTASection />
        <Footer />
      </div>
    </main>
  )
}
