'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowLeft, Check, HelpCircle, Calculator, ArrowRight, Clock, Zap, Shield, Globe, HeadphonesIcon, Code2, Palette, TrendingUp } from 'lucide-react'
import Link from 'next/link'
import { Navbar } from '@/components/layout/Navbar'
import { Footer } from '@/components/layout/Footer'
import { 
  GalacticBackground, 
  ParticleConnections, 
  CustomCursor, 
  GrainOverlay,
  ScrollProgress,
  OrbitingElements
} from '@/components/layout/PageEffects'

const easeLux = [0.16, 1, 0.3, 1] as const

const oneTimePlans = [
  {
    name: 'STARTER',
    price: '€790',
    desc: 'Landing page profesional para startups y emprendedores.',
    duration: '5-7 días',
    features: [
      'Diseño único personalizado',
      '100% responsive móvil',
      'Formulario de contacto',
      'Integración WhatsApp',
      'SEO básico incluido',
      'Hosting 1 año gratis',
      'Soporte 14 días',
      '2 revisiones incluidas',
    ],
    bestFor: 'Startups, landing de producto, páginas de lanzamiento',
    highlight: false
  },
  {
    name: 'BUSINESS',
    price: '€1,490',
    desc: 'Sitio web corporativo completo con CMS para editar contenido.',
    duration: '2-3 semanas',
    features: [
      'Hasta 6 páginas personalizadas',
      'CMS incluido (Sanity)',
      'Blog / noticias integrado',
      'Animaciones elegantes',
      'SEO técnico avanzado',
      'Google Analytics configurado',
      'Integración redes sociales',
      'Hosting 1 año gratis',
      'Soporte 30 días',
      '4 revisiones incluidas',
    ],
    bestFor: 'PYMEs, consultorías, agencias, profesionales independientes',
    highlight: true
  },
  {
    name: 'PREMIUM',
    price: '€2,290',
    desc: 'Sitio web premium con todas las funcionalidades avanzadas.',
    duration: '3-4 semanas',
    features: [
      'Hasta 10 páginas personalizadas',
      'CMS avanzado (Sanity Pro)',
      'Blog + portfolio integrado',
      'Animaciones premium',
      'SEO técnico completo',
      'Multiidioma preparado',
      'Sistema de reservas',
      'Emails transaccionales',
      'Hosting 1 año gratis',
      'Soporte 60 días',
      'Revisiones ilimitadas',
    ],
    bestFor: 'Empresas establecidas, e-commerce pequeño, restaurantes, hoteles',
    highlight: false
  },
]

const addOns = [
  { name: 'Página adicional', price: '+€150', desc: 'Cada página extra que necesites' },
  { name: 'Multiidioma', price: '+€390', desc: 'Preparación para 2+ idiomas' },
  { name: 'E-commerce básico', price: '+€590', desc: 'Tienda con hasta 20 productos' },
  { name: 'Sistema de reservas', price: '+€290', desc: 'Calendar + gestión de citas' },
  { name: 'SEO Avanzado', price: '+€190', desc: 'Audit + optimización + schema' },
  { name: 'Branding completo', price: '+€490', desc: 'Logo + paleta + tipografías' },
]

const subscriptionPlans = [
  {
    name: 'CUIDADO',
    price: '€99',
    period: '/mes',
    desc: 'Mantenimiento esencial para tu sitio web.',
    features: [
      'Actualizaciones de seguridad',
      'Backups semanales automáticos',
      'Monitoreo de uptime 24/7',
      '1 hora de cambios/mes',
      'Soporte por email',
    ],
    bestFor: 'Sitios que necesitan mantenimiento básico',
  },
  {
    name: 'CRECIMIENTO',
    price: '€249',
    period: '/mes',
    desc: 'Soporte activo y mejoras continuas.',
    features: [
      'Todo lo de Cuidado',
      '3 horas de desarrollo/mes',
      'Cambios de contenido ilimitados',
      'Optimización de rendimiento',
      'Soporte prioritario',
      'Informe mensual',
    ],
    bestFor: 'Empresas en crecimiento activo',
    highlight: true
  },
  {
    name: 'PARTNER',
    price: '€499',
    period: '/mes',
    desc: 'Tu equipo de desarrollo dedicado.',
    features: [
      'Todo lo de Crecimiento',
      '8 horas de desarrollo/mes',
      'Nuevas funcionalidades',
      'Landing pages adicionales',
      'Soporte Slack dedicado',
      'Reunión mensual de estrategia',
    ],
    bestFor: 'Empresas con necesidades continuas',
  },
]

const processSteps = [
  { step: '01', title: 'Consulta', desc: 'Llamada de 30 min para entender tu proyecto y objetivos.', time: '1 día' },
  { step: '02', title: 'Propuesta', desc: 'Documento detallado con alcance, precio y timeline.', time: '1-2 días' },
  { step: '03', title: 'Diseño', desc: 'Wireframes + diseño visual. Iteramos hasta que quedes satisfecho.', time: '1-2 semanas' },
  { step: '04', title: 'Desarrollo', desc: 'Construcción con demos semanales para feedback.', time: '1-3 semanas' },
  { step: '05', title: 'Lanzamiento', desc: 'Testing, migración y entrenamiento del equipo.', time: '2-3 días' },
]

const faqs = [
  { q: '¿Qué incluye el precio?', a: 'Diseño, desarrollo, configuración de hosting, SEO técnico y soporte post-lanzamiento. Sin costes ocultos.' },
  { q: '¿Cómo es el proceso de pago?', a: '50% para iniciar, 50% al entregar. Aceptamos transferencia y tarjeta. Para suscripciones, pago mensual.' },
  { q: '¿Tengo el código fuente?', a: 'Sí, 100%. Al finalizar transferimos el repositorio completo a tu GitHub. Sin lock-in.' },
  { q: '¿Puedo editar el contenido?', a: 'Sí, desde el plan Business incluimos CMS (Sanity) para editar textos e imágenes sin saber programar.' },
  { q: '¿Qué pasa si necesito cambios?', a: 'Incluimos soporte gratis (14-60 días según plan). Después puedes contratar mantenimiento o pagar por horas.' },
  { q: '¿Cuánto tiempo tarda?', a: 'Starter: 5-7 días. Business: 2-3 semanas. Premium: 3-4 semanas. Depende de la complejidad y tu feedback.' },
  { q: '¿Ofrecen hosting?', a: 'Configuramos hosting en Vercel (recomendado). El primer año gratis, después pagas directamente (desde gratis).' },
  { q: '¿Trabajan con empresas fuera de España?', a: 'Sí, trabajamos con clientes de toda Europa y Latinoamérica. Comunicación por video y Slack.' },
]

export default function PlanesPage() {
  const [activeTab, setActiveTab] = useState<'one-time' | 'subscription'>('one-time')
  const [traffic, setTraffic] = useState(5000)
  const [conversion, setConversion] = useState(2)
  const [aov, setAov] = useState(50)

  const currentRevenue = traffic * (conversion / 100) * aov
  const projectedRevenue = currentRevenue * 1.25
  const roi = projectedRevenue - currentRevenue

  return (
    <main className="relative min-h-screen bg-[#050505] text-white overflow-x-hidden">
      <GalacticBackground />
      <ParticleConnections />
      <OrbitingElements />
      <GrainOverlay />
      <ScrollProgress />
      <CustomCursor />
      <Navbar />

      <div className="relative z-10 pt-32 pb-20">
        <div className="max-w-6xl mx-auto px-6 sm:px-12 lg:px-24">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: easeLux }}
            className="text-center mb-16"
          >
            <Link
              href="/"
              className="inline-flex items-center gap-2 text-white/30 hover:text-white transition-colors mb-8 text-sm"
            >
              <ArrowLeft size={14} />
              Inicio
            </Link>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-light mb-4">Inversión</h1>
            <p className="text-white/30 max-w-lg mx-auto">
              Precios transparentes. Sin sorpresas. Cada plan diseñado para maximizar tu retorno.
            </p>
          </motion.div>

          {/* Tabs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex justify-center gap-4 mb-16"
          >
            <button
              onClick={() => setActiveTab('one-time')}
              className={`px-6 py-3 text-sm tracking-wider uppercase transition-all ${
                activeTab === 'one-time'
                  ? 'bg-white text-black'
                  : 'border border-white/10 text-white/40 hover:border-white/30'
              }`}
            >
              Proyectos
            </button>
            <button
              onClick={() => setActiveTab('subscription')}
              className={`px-6 py-3 text-sm tracking-wider uppercase transition-all ${
                activeTab === 'subscription'
                  ? 'bg-white text-black'
                  : 'border border-white/10 text-white/40 hover:border-white/30'
              }`}
            >
              Suscripciones
            </button>
          </motion.div>

          {/* Plans */}
          {activeTab === 'one-time' ? (
            <>
              <div className="grid md:grid-cols-3 gap-6 mb-16">
                {oneTimePlans.map((plan, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className={`relative p-8 ${
                      plan.highlight 
                        ? 'border border-white/20 bg-white/[0.02]' 
                        : 'border border-white/5'
                    }`}
                  >
                    {plan.highlight && (
                      <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-white text-black text-xs tracking-wider uppercase">
                        Popular
                      </div>
                    )}
                    <span className="text-xs tracking-[0.15em] text-white/30 uppercase">{plan.name}</span>
                    <div className="text-4xl font-light mt-4 mb-2">{plan.price}</div>
                    <p className="text-sm text-white/40 mb-4">{plan.desc}</p>
                    <div className="text-xs text-white/20 mb-6 flex items-center gap-2">
                      <Clock size={12} />
                      {plan.duration}
                    </div>
                    
                    <ul className="space-y-2 mb-8">
                      {plan.features.map((f, j) => (
                        <li key={j} className="flex items-start gap-2 text-sm text-white/50">
                          <Check size={12} className="text-white/30 mt-0.5 shrink-0" />
                          {f}
                        </li>
                      ))}
                    </ul>
                    
                    <div className="text-xs text-white/20 mb-6 pt-4 border-t border-white/5">
                      <strong className="text-white/40">Ideal:</strong> {plan.bestFor}
                    </div>
                    
                    <Link
                      href="/contacto"
                      className={`block w-full py-3 text-center text-sm tracking-wider uppercase transition-all ${
                        plan.highlight
                          ? 'bg-white text-black hover:bg-white/90'
                          : 'border border-white/10 hover:border-white/30'
                      }`}
                    >
                      Solicitar
                    </Link>
                  </motion.div>
                ))}
              </div>

              {/* Add-ons */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="mb-20"
              >
                <h2 className="text-2xl font-light mb-8">Complementos</h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {addOns.map((addon, i) => (
                    <div key={i} className="flex justify-between items-start p-5 border border-white/5 hover:border-white/10 transition-colors">
                      <div>
                        <h3 className="text-sm mb-1">{addon.name}</h3>
                        <p className="text-xs text-white/30">{addon.desc}</p>
                      </div>
                      <span className="text-sm text-white/50">{addon.price}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            </>
          ) : (
            <div className="grid md:grid-cols-3 gap-6 mb-16">
              {subscriptionPlans.map((plan, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className={`relative p-8 ${
                    plan.highlight 
                      ? 'border border-white/20 bg-white/[0.02]' 
                      : 'border border-white/5'
                  }`}
                >
                  {plan.highlight && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-white text-black text-xs tracking-wider uppercase">
                      Recomendado
                    </div>
                  )}
                  <span className="text-xs tracking-[0.15em] text-white/30 uppercase">{plan.name}</span>
                  <div className="text-4xl font-light mt-4 mb-2">
                    {plan.price}
                    <span className="text-lg text-white/30">{plan.period}</span>
                  </div>
                  <p className="text-sm text-white/40 mb-6">{plan.desc}</p>
                  
                  <ul className="space-y-2 mb-8">
                    {plan.features.map((f, j) => (
                      <li key={j} className="flex items-start gap-2 text-sm text-white/50">
                        <Check size={12} className="text-white/30 mt-0.5 shrink-0" />
                        {f}
                      </li>
                    ))}
                  </ul>
                  
                  <div className="text-xs text-white/20 mb-6 pt-4 border-t border-white/5">
                    <strong className="text-white/40">Ideal:</strong> {plan.bestFor}
                  </div>
                  
                  <Link
                    href="/contacto"
                    className={`block w-full py-3 text-center text-sm tracking-wider uppercase transition-all ${
                      plan.highlight
                        ? 'bg-white text-black hover:bg-white/90'
                        : 'border border-white/10 hover:border-white/30'
                    }`}
                  >
                    Empezar
                  </Link>
                </motion.div>
              ))}
            </div>
          )}

          {/* Process */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-20 py-16 border-t border-white/5"
          >
            <h2 className="text-2xl font-light mb-12 text-center">Proceso de trabajo</h2>
            <div className="grid sm:grid-cols-3 lg:grid-cols-5 gap-8">
              {processSteps.map((step, i) => (
                <div key={i} className="text-center">
                  <div className="text-4xl font-light text-white/10 mb-4">{step.step}</div>
                  <h3 className="text-sm mb-2">{step.title}</h3>
                  <p className="text-xs text-white/30 mb-2">{step.desc}</p>
                  <span className="text-xs text-white/20">{step.time}</span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* ROI Calculator */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-20 py-12 border border-white/5"
          >
            <div className="text-center mb-10">
              <Calculator className="w-6 h-6 mx-auto mb-4 text-white/30" />
              <h2 className="text-2xl font-light">Calculadora ROI</h2>
              <p className="text-sm text-white/30 mt-2">Estima el retorno de tu inversión</p>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 px-4 sm:px-8">
              <div>
                <label className="text-xs text-white/30 block mb-3">Visitantes/mes</label>
                <input
                  type="range"
                  min="500"
                  max="50000"
                  step="500"
                  value={traffic}
                  onChange={(e) => setTraffic(Number(e.target.value))}
                  className="w-full accent-white/50"
                />
                <div className="text-lg mt-2">{traffic.toLocaleString()}</div>
              </div>
              <div>
                <label className="text-xs text-white/30 block mb-3">Conversión (%)</label>
                <input
                  type="range"
                  min="0.5"
                  max="8"
                  step="0.1"
                  value={conversion}
                  onChange={(e) => setConversion(Number(e.target.value))}
                  className="w-full accent-white/50"
                />
                <div className="text-lg mt-2">{conversion}%</div>
              </div>
              <div>
                <label className="text-xs text-white/30 block mb-3">Ticket medio (€)</label>
                <input
                  type="range"
                  min="10"
                  max="300"
                  step="5"
                  value={aov}
                  onChange={(e) => setAov(Number(e.target.value))}
                  className="w-full accent-white/50"
                />
                <div className="text-lg mt-2">{aov}€</div>
              </div>
              <div>
                <label className="text-xs text-white/30 block mb-3">Ingreso extra/mes</label>
                <div className="text-3xl font-light">+{roi.toFixed(0)}€</div>
                <div className="text-xs text-white/20 mt-1">con mejora del 25%</div>
              </div>
            </div>
          </motion.div>

          {/* What's included */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-20 py-12 border-t border-white/5"
          >
            <h2 className="text-2xl font-light mb-10 text-center">Qué incluye cada proyecto</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { icon: Code2, title: 'Código propio', desc: '100% del código es tuyo, sin licencias' },
                { icon: Palette, title: 'Diseño único', desc: 'Sin plantillas, cada diseño es exclusivo' },
                { icon: Shield, title: 'Seguridad', desc: 'HTTPS, CSP headers, protección XSS' },
                { icon: Globe, title: 'Hosting gratis', desc: 'Primer año incluido en todos los planes' },
                { icon: Zap, title: 'Rendimiento', desc: 'Optimizado para Lighthouse 100/100' },
                { icon: TrendingUp, title: 'SEO técnico', desc: 'Schema, meta tags, sitemap XML' },
                { icon: HeadphonesIcon, title: 'Soporte', desc: '14-60 días según el plan' },
                { icon: Clock, title: 'Entrega rápida', desc: 'Desde 5 días para proyectos simples' },
              ].map((item, i) => (
                <div key={i} className="text-center sm:text-left">
                  <item.icon className="w-5 h-5 mb-3 text-white/40" />
                  <h3 className="text-sm mb-1">{item.title}</h3>
                  <p className="text-xs text-white/30">{item.desc}</p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* FAQs */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <div className="text-center mb-10">
              <HelpCircle className="w-6 h-6 mx-auto mb-4 text-white/30" />
              <h2 className="text-2xl font-light">Preguntas frecuentes</h2>
            </div>

            <div className="max-w-2xl mx-auto">
              {faqs.map((faq, i) => (
                <details key={i} className="group border-b border-white/5">
                  <summary className="flex justify-between items-center py-5 cursor-pointer list-none">
                    <span className="text-sm font-light pr-4">{faq.q}</span>
                    <span className="text-white/20 group-open:rotate-45 transition-transform text-xl">+</span>
                  </summary>
                  <div className="pb-5 text-sm text-white/40">{faq.a}</div>
                </details>
              ))}
            </div>
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-20 text-center"
          >
            <p className="text-white/30 mb-6 text-sm">¿No encuentras lo que necesitas?</p>
            <Link
              href="/contacto"
              className="inline-flex items-center gap-2 px-8 py-4 border border-white/10 text-sm tracking-wider uppercase hover:bg-white hover:text-black transition-all"
            >
              Pedir presupuesto personalizado
              <ArrowRight size={14} />
            </Link>
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
