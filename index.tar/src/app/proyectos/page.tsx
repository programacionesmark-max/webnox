'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ArrowLeft, ExternalLink, X, Check, ArrowRight } from 'lucide-react'
import Link from 'next/link'
import { Navbar } from '@/components/layout/Navbar'
import { Footer } from '@/components/layout/Footer'
import { 
  GalacticBackground, 
  ParticleConnections, 
  CustomCursor, 
  GrainOverlay,
  ScrollProgress,
  OrbitingElements
} from '@/components/layout/PageEffects'

const easeLux = [0.16, 1, 0.3, 1] as const

const projects = [
  {
    title: 'NØMADIC CO.',
    category: 'E-Commerce',
    url: 'nomadic.website',
    image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200&q=80',
    desc: 'Tienda online headless con Shopify.',
    detail: 'NØMADIC CO. es una marca de moda sostenible que necesitaba una plataforma e-commerce capaz de soportar su crecimiento internacional. Desarrollamos una arquitectura headless completa usando Shopify Storefront API y Next.js 14. El resultado fue una mejora del 40% en conversión y tiempos de carga inferiores a 200ms globalmente.',
    tech: ['Next.js 14', 'Shopify', 'Vercel', 'Tailwind', 'Framer Motion'],
    stats: [
      { label: 'Conversión', value: '+40%' },
      { label: 'Carga', value: '<200ms' },
      { label: 'Lighthouse', value: '100' },
    ],
    features: ['Arquitectura headless', 'Carrito optimizado', 'Búsqueda instantánea', 'Multi-divisa', 'Panel admin custom']
  },
  {
    title: 'LA CENA BY NOLA',
    category: 'Restaurante',
    url: 'lacenabynola.com',
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1200&q=80',
    desc: 'Web gastronómica con reservas online.',
    detail: 'Restaurante de alta cocina que necesitaba una presencia digital a la altura de su experiencia. El proyecto incluyó sistema de reservas integrado, carta digital interactiva y galería inmersiva. Optimización SEO local consiguiendo primeras posiciones para "restaurante gastronómico" en su zona.',
    tech: ['Next.js 14', 'Sanity CMS', 'TheFork API', 'Cloudinary'],
    stats: [
      { label: 'Reservas online', value: '+85%' },
      { label: 'Tráfico móvil', value: '70%' },
      { label: 'SEO local', value: '#1' },
    ],
    features: ['Sistema reservas', 'Carta digital', 'Galería platos', 'SEO local', 'Instagram feed']
  },
  {
    title: 'A CONTRABARRA',
    category: 'Hospitalidad',
    url: 'acontrabarra.es',
    image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1200&q=80',
    desc: 'Bar de autor con identidad digital única.',
    detail: 'Bar de copas con personalidad única que necesitaba una web que capturara su esencia. Sitio con eventos destacados que se actualizan desde Instagram, carta de cócteles animada y sistema de reservas VIP. Incremento del 120% en visitas al perfil de Google Business.',
    tech: ['Next.js 14', 'Sanity CMS', 'Instagram API', 'GSAP'],
    stats: [
      { label: 'Google visits', value: '+120%' },
      { label: 'Reservas VIP', value: '+65%' },
      { label: 'Nuevos clientes', value: '+45%' },
    ],
    features: ['Carta cócteles animada', 'Eventos dinámicos', 'Reservas VIP', 'Instagram integration', 'SEO local']
  },
]

const services = [
  { title: 'Diseño Web', desc: 'Interfaces elegantes y funcionales' },
  { title: 'Desarrollo Frontend', desc: 'Next.js, React, TypeScript' },
  { title: 'E-commerce', desc: 'Shopify, Stripe, pasarelas' },
  { title: 'CMS Integration', desc: 'Sanity, Strapi, headless' },
  { title: 'SEO Técnico', desc: 'Core Web Vitals, schema' },
  { title: 'Performance', desc: 'Lighthouse 100, optimización' },
]

export default function ProyectosPage() {
  const [selectedProject, setSelectedProject] = useState<number | null>(null)

  return (
    <main className="relative min-h-screen bg-[#050505] text-white overflow-x-hidden">
      <GalacticBackground />
      <ParticleConnections />
      <OrbitingElements />
      <GrainOverlay />
      <ScrollProgress />
      <CustomCursor />
      <Navbar />

      <div className="relative z-10 pt-32 pb-20">
        <div className="max-w-6xl mx-auto px-6 sm:px-12 lg:px-24">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-16"
          >
            <Link
              href="/"
              className="inline-flex items-center gap-2 text-white/30 hover:text-white transition-colors mb-8 text-sm"
            >
              <ArrowLeft size={14} />
              Inicio
            </Link>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-light mb-4">Proyectos</h1>
            <p className="text-white/30 max-w-lg">
              Cada proyecto es único. Sin plantillas, sin atajos. Diseñamos y desarrollamos 
              experiencias digitales que convierten visitantes en clientes.
            </p>
          </motion.div>

          {/* Projects Grid */}
          <div className="grid lg:grid-cols-3 gap-8 mb-20">
            {projects.map((project, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                onClick={() => setSelectedProject(i)}
                className="group cursor-pointer"
              >
                <div className="relative aspect-[3/4] overflow-hidden mb-6">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent opacity-60" />
                </div>
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-xs tracking-wider text-white/30 uppercase mb-1">{project.category}</p>
                    <h2 className="text-xl font-light group-hover:text-white/70 transition-colors">{project.title}</h2>
                    <p className="text-sm text-white/30 mt-2">{project.desc}</p>
                  </div>
                  <ExternalLink size={16} className="text-white/0 group-hover:text-white/40 transition-colors mt-1" />
                </div>
              </motion.div>
            ))}
          </div>

          {/* Services */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="py-16 border-t border-white/5 mb-16"
          >
            <h2 className="text-2xl font-light mb-10">Qué hacemos</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {services.map((service, i) => (
                <div key={i} className="p-5 border border-white/5 hover:border-white/10 transition-colors">
                  <h3 className="text-sm mb-1">{service.title}</h3>
                  <p className="text-xs text-white/30">{service.desc}</p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center py-12 border-t border-white/5"
          >
            <p className="text-white/30 mb-6">¿Tienes un proyecto en mente?</p>
            <Link
              href="/contacto"
              className="inline-flex items-center gap-2 px-8 py-4 border border-white/10 text-sm tracking-wider uppercase hover:bg-white hover:text-black transition-all"
            >
              Hablemos
              <ArrowRight size={14} />
            </Link>
          </motion.div>
        </div>
      </div>

      {/* Modal */}
      <AnimatePresence>
        {selectedProject !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[70] flex items-center justify-center p-6 bg-[#050505]/95 backdrop-blur-sm overflow-y-auto"
            onClick={() => setSelectedProject(null)}
          >
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 30 }}
              className="relative max-w-3xl w-full my-8"
              onClick={e => e.stopPropagation()}
            >
              <button
                onClick={() => setSelectedProject(null)}
                className="absolute top-4 right-4 text-white/30 hover:text-white transition-colors"
              >
                <X size={20} />
              </button>

              <img
                src={projects[selectedProject].image}
                alt={projects[selectedProject].title}
                className="w-full aspect-video object-cover mb-8"
              />

              <div className="px-4">
                <div className="flex items-center gap-4 mb-4">
                  <span className="text-xs tracking-wider text-white/30 uppercase">{projects[selectedProject].category}</span>
                  <a
                    href={`https://${projects[selectedProject].url}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-white/50 hover:text-white flex items-center gap-1"
                  >
                    {projects[selectedProject].url}
                    <ExternalLink size={10} />
                  </a>
                </div>

                <h2 className="text-3xl font-light mb-6">{projects[selectedProject].title}</h2>
                <p className="text-white/40 leading-relaxed mb-8">{projects[selectedProject].detail}</p>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-6 mb-8 p-6 border border-white/5">
                  {projects[selectedProject].stats.map((stat, i) => (
                    <div key={i}>
                      <div className="text-2xl font-light">{stat.value}</div>
                      <div className="text-xs text-white/30">{stat.label}</div>
                    </div>
                  ))}
                </div>

                {/* Features */}
                <div className="mb-8">
                  <span className="text-xs tracking-wider text-white/20 uppercase block mb-4">Características</span>
                  <div className="flex flex-wrap gap-2">
                    {projects[selectedProject].features.map((f, i) => (
                      <span key={i} className="px-3 py-1.5 text-xs border border-white/10 text-white/50">
                        {f}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Tech */}
                <div className="pt-6 border-t border-white/5">
                  <span className="text-xs tracking-wider text-white/20 uppercase block mb-4">Stack</span>
                  <div className="flex flex-wrap gap-2">
                    {projects[selectedProject].tech.map((t, i) => (
                      <span key={i} className="px-3 py-1 text-xs bg-white/5 text-white/40">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-white/5 flex gap-4">
                  <a
                    href={`https://${projects[selectedProject].url}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-6 py-3 bg-white text-black text-sm tracking-wider uppercase hover:bg-white/90 transition-colors"
                  >
                    Ver sitio
                  </a>
                  <button
                    onClick={() => setSelectedProject(null)}
                    className="px-6 py-3 border border-white/10 text-sm tracking-wider uppercase hover:border-white/30 transition-colors"
                  >
                    Cerrar
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <Footer />
    </main>
  )
}
