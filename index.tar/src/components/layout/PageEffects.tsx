'use client'

import { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'

// ============================================================================
// ELEGANT STARS BACKGROUND
// ============================================================================

export function ElegantBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let animationId: number
    let stars: Array<{
      x: number
      y: number
      size: number
      opacity: number
      speed: number
      twinkle: number
    }> = []

    const resize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
      initStars()
    }

    const initStars = () => {
      stars = []
      const count = Math.min(150, Math.floor((canvas.width * canvas.height) / 10000))
      for (let i = 0; i < count; i++) {
        stars.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          size: Math.random() * 1.5 + 0.5,
          opacity: Math.random() * 0.5 + 0.1,
          speed: Math.random() * 0.02 + 0.01,
          twinkle: Math.random() * Math.PI * 2
        })
      }
    }

    const animate = () => {
      ctx.fillStyle = '#050505'
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      stars.forEach(star => {
        star.twinkle += star.speed
        const opacity = star.opacity * (0.5 + Math.sin(star.twinkle) * 0.5)
        
        ctx.beginPath()
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`
        ctx.fill()
      })

      animationId = requestAnimationFrame(animate)
    }

    resize()
    animate()
    window.addEventListener('resize', resize)

    return () => {
      window.removeEventListener('resize', resize)
      cancelAnimationFrame(animationId)
    }
  }, [])

  return (
    <>
      <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-0" />
      {/* Subtle gradient overlays */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-gradient-to-b from-white/[0.02] to-transparent rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-gradient-to-t from-white/[0.015] to-transparent rounded-full blur-3xl" />
      </div>
    </>
  )
}

// ============================================================================
// SUBTLE PARTICLES
// ============================================================================

export function SubtleParticles() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let animationId: number
    let particles: Array<{
      x: number
      y: number
      vx: number
      vy: number
      size: number
    }> = []

    const resize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
      initParticles()
    }

    const initParticles = () => {
      particles = []
      const count = Math.min(30, Math.floor((canvas.width * canvas.height) / 40000))
      for (let i = 0; i < count; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.3,
          vy: (Math.random() - 0.5) * 0.3,
          size: Math.random() * 1.5 + 0.5
        })
      }
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      particles.forEach((p, i) => {
        p.x += p.vx
        p.y += p.vy

        if (p.x < 0 || p.x > canvas.width) p.vx *= -1
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1

        ctx.beginPath()
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
        ctx.fillStyle = 'rgba(255, 255, 255, 0.15)'
        ctx.fill()

        // Elegant connections
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[j].x - p.x
          const dy = particles[j].y - p.y
          const dist = Math.sqrt(dx * dx + dy * dy)

          if (dist < 150) {
            ctx.beginPath()
            ctx.moveTo(p.x, p.y)
            ctx.lineTo(particles[j].x, particles[j].y)
            ctx.strokeStyle = `rgba(255, 255, 255, ${0.03 * (1 - dist / 150)})`
            ctx.stroke()
          }
        }
      })

      animationId = requestAnimationFrame(animate)
    }

    resize()
    animate()
    window.addEventListener('resize', resize)

    return () => {
      window.removeEventListener('resize', resize)
      cancelAnimationFrame(animationId)
    }
  }, [])

  return (
    <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-1 opacity-60" />
  )
}

// ============================================================================
// ELEGANT CURSOR
// ============================================================================

export function ElegantCursor() {
  const cursorRef = useRef<HTMLDivElement>(null)
  const isTouch = typeof window !== 'undefined' && 'ontouchstart' in window

  useEffect(() => {
    if (isTouch) return

    let mouseX = 0
    let mouseY = 0
    let cursorX = 0
    let cursorY = 0

    const handleMouseMove = (e: MouseEvent) => {
      mouseX = e.clientX
      mouseY = e.clientY
    }

    const animate = () => {
      cursorX += (mouseX - cursorX) * 0.12
      cursorY += (mouseY - cursorY) * 0.12

      if (cursorRef.current) {
        cursorRef.current.style.transform = `translate(${cursorX}px, ${cursorY}px)`
      }
      requestAnimationFrame(animate)
    }

    window.addEventListener('mousemove', handleMouseMove)
    animate()

    return () => window.removeEventListener('mousemove', handleMouseMove)
  }, [isTouch])

  if (isTouch) return null

  return (
    <div
      ref={cursorRef}
      className="fixed top-0 left-0 w-px h-16 -translate-x-1/2 pointer-events-none z-[9999] mix-blend-difference"
      style={{ 
        background: 'linear-gradient(to bottom, transparent, white, transparent)',
      }}
    />
  )
}

// ============================================================================
// SUBTLE GRAIN
// ============================================================================

export function SubtleGrain() {
  return (
    <div
      className="fixed inset-0 pointer-events-none z-[100] opacity-[0.015]"
      style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`
      }}
    />
  )
}

// ============================================================================
// SCROLL INDICATOR
// ============================================================================

export function ScrollIndicator() {
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight
      setProgress((window.scrollY / totalHeight) * 100)
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <motion.div
      className="fixed top-0 left-0 h-px bg-white/40 z-[100]"
      style={{ width: `${progress}%` }}
    />
  )
}

// ============================================================================
// FLOATING LINES
// ============================================================================

export function FloatingLines() {
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {/* Elegant vertical lines */}
      <motion.div
        animate={{ y: [0, -100, 0] }}
        transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
        className="absolute left-[10%] top-0 w-px h-full bg-gradient-to-b from-transparent via-white/[0.03] to-transparent"
      />
      <motion.div
        animate={{ y: [0, 100, 0] }}
        transition={{ duration: 25, repeat: Infinity, ease: 'linear' }}
        className="absolute left-[30%] top-0 w-px h-full bg-gradient-to-b from-transparent via-white/[0.02] to-transparent"
      />
      <motion.div
        animate={{ y: [0, -80, 0] }}
        transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
        className="absolute right-[20%] top-0 w-px h-full bg-gradient-to-b from-transparent via-white/[0.02] to-transparent"
      />
      <motion.div
        animate={{ y: [0, 120, 0] }}
        transition={{ duration: 22, repeat: Infinity, ease: 'linear' }}
        className="absolute right-[35%] top-0 w-px h-full bg-gradient-to-b from-transparent via-white/[0.015] to-transparent"
      />
    </div>
  )
}

// ============================================================================
// EXPORT ALL
// ============================================================================

export function CustomCursor() {
  return <ElegantCursor />
}

export function GrainOverlay() {
  return <SubtleGrain />
}

export function ScrollProgress() {
  return <ScrollIndicator />
}

export function GalacticBackground() {
  return <ElegantBackground />
}

export function ParticleConnections() {
  return <SubtleParticles />
}

export function FloatingCode() {
  return null
}

export function FloatingIcons() {
  return null
}

export function TerminalEffect() {
  return null
}

export function OrbitingElements() {
  return <FloatingLines />
}

export function MatrixRain() {
  return null
}
